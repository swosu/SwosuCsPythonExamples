import matplotlib.pyplot as plt
import pandas as pd

file1 = input()
file2 = input()

# TODO: Read in .csv files as dataframes

# TODO: Print each dataframe individually

# TODO: Create plots for both July and December in one image

plt.savefig('subplots.png')