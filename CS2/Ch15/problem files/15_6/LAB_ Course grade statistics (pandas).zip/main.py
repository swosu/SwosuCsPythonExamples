import pandas as pd

file_name = input()

# TODO: Read in file_name as a dataframe

# TODO: Output rows by descending Final scores

print("\nMax Scores:")

# TODO: Output the max scores of each assignment

print("\nMedian Scores:")

# TODO: Output the median scores of each assignment

print("\nAverage Scores:")

# TODO: Output the average scores of each assignment.

print("\nStandard Deviation:")

# TODO: Output the standard devation of each assignment.